<?php

/*
__PocketMine Plugin__
name=UPvP
version=2.0
author=1ron_pon3
class=upvp
apiversion=11
*/

class upvp implements Plugin{
	private $api;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->server = ServerAPI::request();
	}
	
	public function init(){
		$this->api->console->register("pvp", "Toggle PvP", array($this, "command"));
		$this->api->console->register("upvp", "UPvP manager", array($this, "command"));
		$this->api->ban->cmdWhitelist("pvp");
		$this->api->addHandler("player.interact", array($this,"handler"), 5);
		$this->api->addHandler("player.death", array($this,"handler"), 5);
		$this->readConfig();
	}
	
    public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array(
		 "pvp-announce" => "true",
		 "pvp-night" => "true",
		 "default" => "on",
		 "msg" => array(
		 "pvp-enable" => "@player now in pvp mode!",
		 "pvp-disable" => "@player disabled pvp!",
		 "pvp-output-on" => "PvP enabled!",
		 "pvp-output-off" => "PvP disabled!",		 
		 "pvp-enable-global" => "PvP is now enabled on the server!",
		 "pvp-disable-global" => "PvP is now disabled on the server!",
		 "t-pvp-off" => "You can't hit this player! He isn't in PvP mode!",
		 "p-pvp-off" => "You can't hit anybody! You are not in PvP mode!",
		 "pvp-off" => "PvP is disabled on this server now!",
		 "new-lvl" => "@player is now @lvl!"
		 ),
		 "lvl" => array(
		 "announce" => "true",
		 "1-name" => "1",
		 "1-exp" => "0",
		 "2-name" => "2",
		 "2-exp" => "5",
		 "3-name" => "3",
		 "3-exp" => "20",
		 "4-name" => "4",
		 "4-exp" => "50",
		 "5-name" => "5",
		 "5-exp" => "100"
		 )
		 ));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
	  if(!file_exists($this->path."userdata.yml")){
      $c = new Config($this->path."userdata.yml", CONFIG_YAML, array());}
      $this->udata = $this->api->plugin->readYAML($this->path."userdata.yml");
	
	}
	
	public function __destruct(){
	 $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
	 $this->api->plugin->writeYAML($this->path."userdata.yml", $this->udata);
	}
	
    public function command($cmd, $args, $issuer){
	  switch($cmd){
	    case "pvp":
		  switch($args[0]){
		    //Change pvp status
	        case "": 
	          $player= $issuer->username;
	          if(!isset($this->udata[$player]['pvp']))
		      {
	            $this->udata[$player]['pvp']=1;
	            $output=$this->config['msg']["pvp-output-on"];
	            if($this->config['pvp-announce']==true)
			    {
	              $broadcast=str_replace(array("@player"), array($player), $this->config['msg']["pvp-enable"]);
	              $this->api->chat->broadcast($broadcast);
	            }
	          }
	          else
		      {
	            unset($this->udata[$player]['pvp']); 
	            $output=$this->config ['msg'] ["pvp-output-off"];
	            if($this->config['pvp-announce']==true)
			    {
	              $broadcast=str_replace(array("@player"), array($player), $this->config['msg']["pvp-disable"]);
	              $this->api->chat->broadcast($broadcast);
	            }
	          }
		    break;
		    //Player list
			case "list":
			  $output .= "==============================\n";
			  $output .= "* ".count($this->server->clients)."/".$this->server->maxClients." players online\n";
			  $output .= "------------------------------\n";
		      $output .= "* Players with PvP enabled: \n";
              foreach($this->server->clients as $c)
		      {
			    $player=$c->username;
			    If(isset($this->udata[$player]['pvp']))
				{
                  $output .= $c->username.", ";
				}
              }
			  $output = substr($output, 0, -2)."\n";
			  $output .= "------------------------------\n";
			  $output .= "* Players with PvP disabled: \n";
              foreach($this->server->clients as $c)
		      {
			    $player=$c->username;
			    If(!isset($this->udata[$player]['pvp']))
				{
                  $output .= $c->username.", ";
				}
              }
			  $output = substr($output, 0, -2)."\n";
			  $output .= "==============================\n";
		    break;
			//See rank
		    case "rank":
		      $player= $issuer->username;
		      $kills= $this->udata[$player]['k'];
		      $deaths= $this->udata[$player]['d'];
		      $exp=$kills-$deaths;
		      if($exp<$this->config['lvl']['2-exp']){$level=$this->config['lvl']['1-name']; }
		      elseif($exp<$this->config['lvl']['3-exp']){$level=$this->config['lvl']['2-name']; }
		      elseif($exp<$this->config['lvl']['4-exp']){$level=$this->config['lvl']['3-name']; }
		      elseif($exp<$this->config['lvl']['5-exp']){$level=$this->config['lvl']['4-name']; }
		      elseif($exp>=$this->config['lvl']['5-exp']){$level=$this->config['lvl']['5-name']; }
		      $output .= "==============================\n";
			  $output .= "* UPvP Rank: ".$player."\n";
			  $output .= "------------------------------\n";
			  $output .= "Kills: ".$kills."\n";
			  $output .= "Deaths: ".$deaths."\n";
			  $output .= "------------------------------\n";
			  $output .= "Exp: ".$exp."\n";
			  $output .= "Level: ".$level."\n";
			  $output .= "==============================\n";
			  break; 		    
		}
	    break;
		
	    case "upvp":
	      switch($args[0]){
		    //Nothing.
	        case "":
	          $output="UPvP Manager by 1ron_pon3. \n Use /upvp help for list of commands";
	        break;
			//Set global pvp
	        case "set":
	          if($args[1]=="on")
			  {
	            $this->config['default']="on";
	            $output=$this->config['msg']["pvp-enable-global"];
	          }
	          elseif($args[1]=="off")
			  {
	            $this->config['default']="off";
	            $output=$this->config['msg']["pvp-disable-global"];
	          }
	          else
	          {
	            $output="on/off";
	          }
	        break;
		    //Reload config
			case "reload":
		      $this->readConfig();
		      $output="Config reloaded!";
		    break;
		    //Cmd list
			case "help":
		      $output="UPvP commands:\n";
		      $output.="/pvp - change your pvp status\n";
		      $output.="/pvp list - show other players' pvp status\n";
			  $output.="/pvp rank - show rank\n";			  
		      $output.="/upvp set on/off - Global PvP control\n";
		      $output.="/upvp reload - reload config\n";
			  $output.="/upvp save - save config\n";
			  $output.="/upvp rank @player - @player's rank\n";			  
		    break;
			//Another player's rank
		    case "rank":
		      $player= $args[1];
		      $kills= $this->udata[$player]['k'];
		      $deaths= $this->udata[$player]['d'];
		      $exp=$kills-$deaths;
		      if($exp<$this->config['lvl']['2-exp']){$level=$this->config['lvl']['1-name']; }
		      elseif($exp<$this->config['lvl']['3-exp']){$level=$this->config['lvl']['2-name']; }
		      elseif($exp<$this->config['lvl']['4-exp']){$level=$this->config['lvl']['3-name']; }
		      elseif($exp<$this->config['lvl']['5-exp']){$level=$this->config['lvl']['4-name']; }
		      elseif($exp>=$this->config['lvl']['5-exp']){$level=$this->config['lvl']['5-name']; }
		      $output .= "==============================\n";
			  $output .= "* UPvP Rank: ".$player."\n";
			  $output .= "------------------------------\n";
			  $output .= "Kills: ".$kills."\n";
			  $output .= "Deaths: ".$deaths."\n";
			  $output .= "------------------------------\n";
			  $output .= "Exp: ".$exp."\n";
			  $output .= "Level: ".$level."\n";
			  $output .= "==============================\n"; 		    
            break;
			//Save config
	        case "save":
		  	  $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
	          $this->api->plugin->writeYAML($this->path."userdata.yml", $this->udata);
	        break;
		  }
	    break;
	  }
	  return $output;
	}
	 
	 public function handler($data, $event){
       switch($event){
         case "player.interact":
		   $target1=$data["targetentity"]->class;
           if($target1=="1")
		   {
		     $target=$data["targetentity"]->player->username;
             $player=$data['entity']->player->username;
		     if($this->config['default']=="off") //PvP turned off
             {
               $this->api->chat->sendTo(false, $this->config['msg']['pvp-off'], $player);
               return false;
             }
			 else
			 {
		       if($this->config['pvp-night']== "true" && $this->api->time->getPhase() == "night") //PvP night
			   {
                 return true;
			   }
               elseif(!isset($this->udata[$player]['pvp'])) //Player's pvp not enabled
               {
                 $this->api->chat->sendTo(false, $this->config['msg']['p-pvp-off'], $player);
                 return false;
               }
               elseif(!isset($this->udata[$target]['pvp'])) //Target's pvp not enabled
               {
                 $this->api->chat->sendTo(false, $this->config['msg']['t-pvp-off'], $player);
                 return false;
               }
               else
               {
			     return true;
               }			   
             }
           }
         break;
		 case "player.death":
           $player = $this->api->entity->get($data["cause"]);
		   $dead=$data["player"]->username;
		   //Add kills for killer
		   if($player instanceof Entity)
		   {
			  $player = $player->name; 
		   }
		   If(!isset($this->udata[$player]['k']))
		   {
		     $this->udata[$player]['k']=1;
		   }
		   else 
		   {
		     $this->udata[$player]['k']=$this->udata[$player]['k']+1;
		   }
		   //Add deaths for looser
		   If(!isset($this->udata[$dead]['d']))
		   {
		     $this->udata[$dead]['d']=1;
		   }
		   else 
		   {
		     $this->udata[$dead]['d']=$this->udata[$dead]['d']+1;
		   }
		   //New level	
		   if($this->config['lvl']['announce']== "true")
		   {
		   	$kills= $this->udata[$player]['k'];
		    $deaths= $this->udata[$player]['d'];
		    $exp=$kills-$deaths;
		    if($exp==$this->config['lvl']['2-exp'])
			{ 
			  $broadcast=str_replace(array("@player", "@lvl"), array($player, $level=$this->config['lvl']['2-name']), $this->config['msg']["new-lvl"]);
	          $this->api->chat->broadcast($broadcast);
			}
		    elseif($exp==$this->config['lvl']['3-exp'])
			{ 
			  $broadcast=str_replace(array("@player", "@lvl"), array($player, $level=$this->config['lvl']['3-name']), $this->config['msg']["new-lvl"]);
	          $this->api->chat->broadcast($broadcast);			
			}
		    elseif($exp==$this->config['lvl']['4-exp'])
			{ 
			  $broadcast=str_replace(array("@player", "@lvl"), array($player, $level=$this->config['lvl']['4-name']), $this->config['msg']["new-lvl"]);
	          $this->api->chat->broadcast($broadcast);			
			}
		    elseif($exp==$this->config['lvl']['5-exp'])
			{ 
			  $broadcast=str_replace(array("@player", "@lvl"), array($player, $level=$this->config['lvl']['5-name']), $this->config['msg']["new-lvl"]);
	          $this->api->chat->broadcast($broadcast);			
			}
           } 			
		 break;
     }}
	 
	}